package com.example.cuatroenrayaLucas.views

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.support.design.widget.Snackbar
import android.support.v4.content.ContextCompat
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.example.cuatroenrayaLucas.R
import com.example.cuatroenrayaLucas.model.TableroConecta4
import com.example.cuatroenrayaLucas.utility.setColor
import com.example.cuatroenrayaLucas.utility.setColorChip
import es.uam.eps.multij.Tablero
import kotlinx.android.synthetic.main.fragment_round.view.*

/**
 * @brief Clase ERView para manejar mejor el temaño del tablero en funcion de la pantalla
 */
class ChipView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var heightOfTile: Float = 0.toFloat()
    private var widthOfTile: Float = 0.toFloat()
    private var radio: Float = 0.toFloat()
    private var turno: Int = 0

    init {
        backgroundPaint.color = ContextCompat.getColor(context, R.color.colorTablero)
        linePaint.strokeWidth = 2f
    }

    /**
     * @brief funcion para controlar el tamanio de las cosas en funcion de la pantalla
     * @param w anchura
     * @param h altura
     * @param oldw antigua anchura
     * @param oldh antigua altura
     *
     */
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        widthOfTile = (w / 1.5).toFloat()
        heightOfTile = (h / 1.5).toFloat()
        if (widthOfTile < heightOfTile)
            radio = widthOfTile * 0.3f
        else
            radio = heightOfTile * 0.3f
        super.onSizeChanged(w, h, oldw, oldh)
    }

    /**
     * @brief dibuja el tablero
     * @param canvas el canvas donde pintar
     *
     */
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawCircles(canvas, linePaint)
    }

    /**
     * @brief dibuja las fichas
     * @param canvas el canvas donde pintar
     * @param paint el canvas donde pintar
     *
     */
    private fun drawCircles(canvas: Canvas, paint: Paint) {
        var centerRaw: Float
        var centerColumn: Float
        val pos =  0
        centerRaw = heightOfTile * (1 + 2 * pos) / 2f
        centerColumn = widthOfTile * (1 + 2 * 0) / 2f

        paint.setColorChip(0, 0, turno, this.context)
        canvas.drawCircle(centerColumn, centerRaw, radio, paint)
    }


    /**
     * @brief calcula el tamanio de la pantalla
     * @param widthMeasureSpec anchura
     * @param heightMeasureSpec altura
     *
     */
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val desiredWidth = 500
        val wMode: String
        val hMode: String
        val widthMode = View.MeasureSpec.getMode(widthMeasureSpec)
        var widthSize = View.MeasureSpec.getSize(widthMeasureSpec)
        val heightMode = View.MeasureSpec.getMode(heightMeasureSpec)
        var heightSize = View.MeasureSpec.getSize(heightMeasureSpec)
        val width: Int
        val height: Int
        if (widthSize < heightSize) {
            heightSize = widthSize
            height = heightSize
            width = height
        } else {
            widthSize = heightSize
            height = widthSize
            width = height
        }
        setMeasuredDimension(width,height)
    }

    /**
     * @brief settea el tablero
     * @param board tablero a setear
     *
     */
    fun setTurno(turno: Int) {
        this.turno = turno
    }
}