/**
 * 
 * @author Alvaro Caseiro Moreno y Daniel Serena Sanz
 * @date 18/03/2019
 * @grupo 7
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/types.h>
#include <limits.h>

#define NUM 3

enum colores {
    rojo = 0, azul, blanco, verde
};

/**
 * @brief Lee los valores de los gpio 50 y 51
 * @param val1 gpio 50
 * @param val2 gpio 51
 * @return -1 si error
 */
int leerValorGpios(int *val1, int *val2);
/**
 * @brief Cambia los valores de los gpio 50 y 51
 * @param val1 gpio 50
 * @param val2 gpio 51
 * @return -1 si error
 */
int cambiarValorGpios(int val1, int val2);
/**
 * @brief calcula la media de un array
 * @param datos array
 * @return media
 */
int calcularMedia(int datos[NUM]);
/**
 * @brief leer valor RGB
 * @return valor leido del sensor rgb 
 */
int getValue();

int main(int argc, char ** argv) {

    char * coloresCharArray[4] = {"Rojo", "Azul", "Blanco", "Verde"};
    
    float medidas_total = 0;

    int i = 0, j = 0, k = 0;

    int acumulador[NUM];
    float medidas[4];
    int antes = 0, despues = 0;

    FILE * fd = NULL;


    int valor = 0, val1 = 0, val2 = 0;

    int gpio1[] = {0, 0, 1, 1};
    int gpio2[] = {0, 1, 0, 1};

    float porcentaje = 0;


    for (i = 0; i < 4; i++) {
        cambiarValorGpios(gpio1[i], gpio2[i]);
        printf("Midiendo porcentaje de %s\n", coloresCharArray[i]);
        for (k = 0; k < NUM; k++) {
            antes = getValue();
            sleep(1);
            despues = getValue();
            acumulador[k] = despues - antes;
            /*printf("Medida %d hecha, valor:\t%d\n", k + 1, acumulador[k]);*/

        }
        getchar();
        medidas[i] = calcularMedia(acumulador);
    }

    /*printf("\n\n");
    for (i = 0; i < 4; i++) {
        printf("Medidas %d : %.2f\n", i, medidas[i]);
    }*/
    medidas[0] /= medidas[2];
    medidas[1] /= medidas[2];
    medidas[3] /= medidas[2];

   /* printf("---------------------------------------------\n");

    for (i = 0; i < 4; i++) {
        printf("%.8f\t", medidas[i]);
    }
    printf("\n---------------------------------------------\n");*/

    medidas_total = medidas[0] + medidas[1] + medidas[3];
    /*printf("medidas_total %.2f\n", medidas_total);*/

    medidas[0] = medidas[0] / medidas_total * 100;
    medidas[1] = medidas[1] / medidas_total * 100;
    medidas[3] = medidas[3] / medidas_total * 100;
    
    medidas_total = medidas[0] + medidas[1] + medidas[3];
    
    medidas[0] = medidas[0] + medidas_total * 9 / 100;
    medidas[1] = medidas[1] - medidas_total * 26 / 100;
    medidas[3] = medidas[3] + medidas_total * 16 / 100;

    for (i = 0; i < 4; i++) {
        if (i != 2) {
            printf("Porcentaje de %s: %.2f\n", coloresCharArray[i], medidas[i]);
        }
    }
}

int cambiarValorGpios(int val1, int val2) {
    FILE * fd = NULL;
    char str[5] = "";
    sprintf(str, "%d", val1);
    fd = fopen("/sys/class/gpio/gpio50/value", "w+");
    if (fd == NULL) {
        return -1;
    }
    fprintf(fd, str);
    fclose(fd);
    memset(str, 0, strlen(str));
    sprintf(str, "%d", val2);
    fd = fopen("/sys/class/gpio/gpio51/value", "w+");
    if (fd == NULL) {
        printf("LINE %d", __LINE__);
        return -1;
    }
    fprintf(fd, str);
    fclose(fd);
}

int getValue() {
    int valor = 0;
    FILE * fd = NULL;
    char str[1000] = "";

    fd = fopen("/proc/interrupts", "r");
    if (fd == NULL) {
        return -1;
    }
    while (fscanf(fd, "%s", str) != EOF) {

        if (strstr(str, "226:") != NULL) {
            fscanf(fd, "%s", str);
            valor = atoi(str);
        }
    }
    fclose(fd);
    return valor;

}

int calcularMedia(int datos[NUM]) {

    int i = 0;
    int sum = 0;
    for (i = 0; i < NUM; i++) {
        sum += datos[i];
    }

    return sum / NUM;


}

int leerValorGpios(int *val1, int *val2) {
    FILE * fd = NULL;
    char str[5] = "";
    sprintf(str, "%d", val1);
    fd = fopen("/sys/class/gpio/gpio50/value", "r");
    if (fd == NULL) {
        return -1;
    }
    fscanf(fd, "%s", str);
    *val1 = atoi(str);
    fclose(fd);
    memset(str, 0, strlen(str));
    sprintf(str, "%d", val2);
    fd = fopen("/sys/class/gpio/gpio51/value", "r");
    if (fd == NULL) {
        printf("LINE %d", __LINE__);
        return -1;
    }
    fscanf(fd, "%s", str);
    *val2 = atoi(str);
    fclose(fd);
}