# DADM_4
DADM_4

Práctica 2 - Creación aplicación móvil.

Conecta 4 made by:
  - Daniel Serena Sanz (https://github.com/danielss24)
  - Lucas Ruiz Palomares (https://github.com/LucasR8)
